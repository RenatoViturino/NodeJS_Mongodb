var rect = require('./rectangle1');

function solveRect(l, b) {
	console.log("Solving  for rectangle with l= " + l + " and b= " + b);
	if (l < 0 || b < 0) {
		console.log("Rectangle dimensions should zero: l= " + l + ", and b= "
				+ b);
	} else {
		console.log("the area of rectangle of dimensions l= " + l
				+ ", and breadth b= " + b + " is " + rect.area(l, b));
		console.log("The perimeter of  a retangle  of dimensions leght = " + l
				+ " and breadth = " + b + " is " + rect.area(l, b));

	}

}

