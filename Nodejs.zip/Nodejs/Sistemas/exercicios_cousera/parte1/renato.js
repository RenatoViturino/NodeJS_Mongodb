var tp= 'renato';
console.log(tp);