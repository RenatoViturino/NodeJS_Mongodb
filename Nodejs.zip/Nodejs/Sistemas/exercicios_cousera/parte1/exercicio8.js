var http= require('http');

var createRoute = function (port){
	var api={};
	var routes={};
	var methods= ['GET', 'POST','OPTIONS'];
	var interceptors[];
	methods.forEach(function (method) {
		routes[method]={};
		api[method.toLowerCase()]= function(path,fn){
			routes[method][path]=fn;
			
		};
	});
	
	api.interceptor= function(interceptor){
		interceptors.push(interceptor);
	};
	var  executeInterceptor= function(number,req,res){
		var interceptor= inteceptors[number];
		if(!inteceptor)return;
		interceptor(req,res,function(){
			executeInterceptor(++number,req,res);
		});
	};
	
	var headleBody= function(req,res,next){
		var body[];
		req.on('data',function(chunk){
			body.push(chunk);
		});
		req.on('end',function(){
			req.body=Buffer.concat(body).toString();
		});
		next();
	};
	
	
	http.createServer(function(req,res ){
		headleBody(req,res,function(){
			executeInterceptor(0,req,res);
			res.setHeader('Acess-Control-Allow-Origin','*');
			if(!routes[req.method][req.url]) 
				res.statusCode="404";
				return res.end();
			 routes[req.method][res.url](req,res);
		})
	
		 
	}).listen(port);
	return api;
	}
module.exports= createRouter;